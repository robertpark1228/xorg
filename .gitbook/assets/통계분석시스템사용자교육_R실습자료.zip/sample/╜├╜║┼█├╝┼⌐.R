# system.time(print())

# Example 1
system.time(print(a1 <- read.table("C:/Users/charlie/Desktop/HIRA/1.4 R��� ������ �м�/Data/SAMPLING_NPS_ALL_YKIHO_2013.txt", header=T, sep=",")))

# Example 2
system.time(for(i in 1:100) mad(runif(1000)))



# ** sample data ----------------------------------------------------------


# Example 1
sample_20 <- read.table("C:/Users/charlie/Desktop/HIRA/1.4 R��� ������ �м�/Data/SAMPLE_NPS_2013_20_01.txt", header=T, sep=",",  nrows=7000)
head(sample_20)
str(sample_20)
summary(sample_20)
View(sample_20)

save(sample_20,file="sample_20.Rdata")

# Example 2
sample_30 <- read.table("C:/Users/charlie/Desktop/HIRA/1.4 R��� ������ �м�/Data/SAMPLE_NPS_2013_30_01.txt", header=T, sep=",",  nrows=7000)
head(sample_30)
str(sample_30)
summary(sample_30)
View(sample_30)

save(sample_30,file="sample_30.Rdata")

# Example 3
sample_40 <- read.table("C:/Users/charlie/Desktop/HIRA/1.4 R��� ������ �м�/Data/SAMPLE_NPS_2013_40_01.txt", header=T, sep=",",  nrows=7000)
head(sample_40)
str(sample_40)
summary(sample_40)
View(sample_40)

save(sample_40,file="sample_40.Rdata")


# Example 4
sample_53 <- read.table("C:/Users/charlie/Desktop/HIRA/1.4 R��� ������ �м�/Data/SAMPLE_NPS_2013_53_01.txt", header=T, sep=",",  nrows=7000)
head(sample_53)
str(sample_53)
summary(sample_53)
View(sample_53)

save(sample_53,file="sample_53.Rdata")

# Example 5
YKIHO <- read.table("C:/Users/charlie/Desktop/HIRA/1.4 R��� ������ �м�/Data/SAMPLING_NPS_ALL_YKIHO_2013.txt", header=T, sep=",")
head(YKIHO)
str(YKIHO)
summary(YKIHO)
View(YKIHO)

save(YKIHO,file="sample_YKIHO.Rdata")
