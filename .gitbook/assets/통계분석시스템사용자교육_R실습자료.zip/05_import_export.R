###################################################
### 데이터 입출력
###################################################
# free memory
rm(list = ls())
gc()


###################################################
### 생성 데이터 저장 후 로드
###################################################
a <- 1:10

save(a, file="C:/Rpackages/data/dumData.Rdata")

# 메모리에서 a 데이터 삭제
rm(a)

load("C:/Rpackages/data/dumData.Rdata")

print(a)


###################################################
### 데이터 프레임 생성
###################################################
var1 <- 1:5
var2 <- (1:5) / 10
var3 <- c("R", "and", "Data Mining", "Examples", "Case Studies")
df1 <- data.frame(var1, var2, var3)
names(df1) <- c("VariableInt", "VariableReal", "VariableChar")
write.csv(df1, "C:/Rpackages/data/dummmyData.csv", row.names = FALSE)
df2 <- read.csv("C:/Rpackages/data/dummmyData.csv")
print(df2)


###################################################
### SAS 사용
###################################################

library(foreign)

# the path of SAS
sashome <- "C:/Program Files/SAS/SASFoundation/9.2"
filepath <- "C:/Rpackages/data"

# filename should be no more than 8 characters, without extension
fileName <- "dumData"

# read data from a SAS dataset
a <- read.ssd(file.path(filepath), fileName, sascmd=file.path(sashome, "sas.exe"))
print(a)


###################################################
### CSV file에서 variable names 읽어 들이기
###################################################

# read variable names from a .CSV file
variableFileName <- "dumVariables.csv"
filepath<-"C:/Users/charlie/Desktop/HIRA/1.4 R통계 데이터 분석/R/R_analysis/data"

# 사용예시
# myNames <- read.csv(paste(filepath, variableFileName, sep="/"))
variableFileName <- "dumVariables.csv"
myNames <- read.csv(paste(filepath, variableFileName, sep="/"))
names(a) <- names(myNames)
print(a)




###################################################
### RODBC 연결을 통한 데이터 import / export
###################################################
## library(RODBC)
## connection <- odbcConnect(dsn="servername",uid="userid",pwd="******")
## query <- "SELECT * FROM lib.table WHERE ..."
## # 또는 작성된 쿼리로 읽어 들이는 방법(작성 쿼리 : myQuery.sql)
## # query <- readChar("data/myQuery.sql", nchars=99999)
## myData <- sqlQuery(connection, query, errors=TRUE)
## odbcClose(connection)


###################################################
### RODBC 연결을 통한 데이터 excel 파일 import / export
###################################################
## library(RODBC)
## filename <- "data/dummmyData.xls"
## xlsFile <- odbcConnectExcel(filename, readOnly = FALSE)
## sqlSave(xlsFile, a, rownames = FALSE)
## b <- sqlFetch(xlsFile, "a")
## odbcClose(xlsFile)
