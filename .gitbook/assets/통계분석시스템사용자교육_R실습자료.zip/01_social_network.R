###################################################
### 실행준비
###################################################

# 메모리 지우기
rm(list = ls())

# 실행중인 라이브러리 지우기
gc()


###################################################
### 데이터 로드 -아스키형태 or DB 추출(RODBC 활용)
###################################################

# 디렉토리 설정
setwd("C:/Rpackages")

# termDocMatrix 데이터 불러오기
load("C:/Users/rober/Desktop/통계분석시스템사용자교육_R실습자료/sample/termDocMatrix.rdata")

#데이터 확인
termDocMatrix

# 데이터의 행렬검사
termDocMatrix[5:10,1:20]

# Boolean matrix 전환 : 0과 1로
termDocMatrix[termDocMatrix>=1] <- 1

#데이터 확인
termDocMatrix

# 인접 행령도 전환 : term-term adjacency matrix
termMatrix <- termDocMatrix %*% t(termDocMatrix)

#데이터 확인
termMatrix

# inspect terms numbered 5 to 10
termMatrix[5:10,5:10]


###################################################
### 그래프 출력 전 데이터 크리닝하기
###################################################

# 그래프 라이브러리 호출
library(igraph)

# build a graph from the above matrix
g <- graph.adjacency(termMatrix, weighted=T, mode="undirected")

# remove loops
g <- simplify(g)

# set labels and degrees of vertices
V(g)$label <- V(g)$name
V(g)$degree <- degree(g)


###################################################
### SNA 그래프 출력하기
###################################################

# set seed to make the layout reproducible
set.seed(3952)
layout1 <- layout.fruchterman.reingold(g)

# 기본 plot
plot(g, layout=layout1)

# 변형 plot
plot(g, layout=layout.kamada.kawai)

# R Graph 개체 띄우기
tkplot(g, layout=layout.kamada.kawai)

###################################################
### 확장 또는 확대해서 그래프 출력해서 보기
###################################################
V(g)$label.cex <- 2.2 * V(g)$degree / max(V(g)$degree)+ .2
V(g)$label.color <- rgb(0, 0, .2, .8)
V(g)$frame.color <- NA
egam <- (log(E(g)$weight)+.4) / max(log(E(g)$weight)+.4)
E(g)$color <- rgb(.5, .5, 0, egam)
E(g)$width <- egam

# 그래프 : 화면 해상도에 따라 라인이 안보일 수 있음(R 버그)
plot(g, layout=layout1)