###################################################
### boxplot 그래프로 이상치 탐색
###################################################
# free memory
rm(list = ls())
gc()

# 랜덤 데이터 생성
set.seed(3147)

# 정규분포화
x <- rnorm(100)

# 데이터 요약
summary(x)

# outliers 탐색
boxplot.stats(x)$out
boxplot(x)


###################################################
### scatter 그래프로 이상치 탐색
###################################################
y <- rnorm(100)
df <- data.frame(x, y)
rm(x, y)
head(df)
attach(df)

# 이상치 인덱스 만들기
(a <- which(x %in% boxplot.stats(x)$out))
(b <- which(y %in% boxplot.stats(y)$out))
detach(df)

(outlier.list1 <- intersect(a,b))
plot(df)
points(df[outlier.list1,], col="red", pch="+", cex=2.5)

# outliers in either x or y
(outlier.list2 <- union(a,b))
plot(df)
points(df[outlier.list2,], col="blue", pch="x", cex=2)


###################################################
### DMwR(LOF-Local Outlier Factor algorithm) 이상치
###################################################
library(DMwR)
# remove "Species", which is a categorical column
iris2 <- iris[,1:4]
outlier.scores <- lofactor(iris2, k=5)
plot(density(outlier.scores))


###################################################
### biplot 그래프로 이상치 탐색
###################################################
n <- nrow(iris2)
labels <- 1:n
biplot(prcomp(iris2), cex=.8, xlabs=labels)
