###################################################
### 시계열(time series)
###################################################
# free memory
rm(list = ls())
gc()


###################################################
### 시계열 데이터 생성
###################################################
a <- ts(1:30, frequency=12, start=c(2011,3))
print(a)
str(a)
attributes(a)

plot(a)

###################################################
### AirPassengers 데이터 예제를 활용한 시계열 분석
###################################################
plot(AirPassengers)


###################################################
### code chunk number 4: ch-time-series.rnw:57-68
###################################################
# decompose time series
# 추세, 계절성/순환적 요소를 구분(decompose)
apts <- ts(AirPassengers, frequency=12)
f <- decompose(apts)

# seasonal figures
f$figure
plot(f$figure, type="b", xaxt="n", xlab="")

# 그래프 메인 제목
plot(f$figure, type="b", xaxt="n", xlab="", main="제목을 넣어 주세요")

# 그래프 유형 예제
plot(f$figure, type="b", xaxt="n", xlab="", main="제목을 넣어 주세요")
plot(f$figure, type="p", xaxt="n", xlab="", main="제목을 넣어 주세요")
plot(f$figure, type="l", xaxt="n", xlab="", main="제목을 넣어 주세요")
plot(f$figure, type="s", xaxt="n", xlab="", main="제목을 넣어 주세요")
plot(f$figure, type="h", xaxt="n", xlab="", main="제목을 넣어 주세요")


# Jan -> 1월 형식으로 변경하기
monthNames <- months(ISOdate(2011,1:12,1))

# 데이터 확인
monthNames

# x축에 1월~12월 이름을 2 간격으로 표시(option : las=2)
axis(1, at=1:12, labels=monthNames, las=2) 

plot(f)


###################################################
### ARIMA Time Series
###################################################
fit <- arima(AirPassengers, order=c(1,0,0), list(order=c(2,1,0), period=12))
fore <- predict(fit, n.ahead=24)

# 95% 신뢰수준
U <- fore$pred + 2*fore$se
L <- fore$pred - 2*fore$se
ts.plot(AirPassengers, fore$pred, U, L, col=c(1,2,4,4), lty = c(1,1,2,2))
legend("topleft", c("Actual", "Forecast", "Error Bounds (95% Confidence)"),
       col=c(1,2,4), lty=c(1,1,2))

###################################################
### dtw(Dynamic Time Warp) 라이브러리 활용 시계열 이동평균
###################################################
library(dtw)
idx <- seq(0, 2*pi, len=100)
a <- sin(idx) + runif(100)/10
b <- cos(idx)
align <- dtw(a, b, step=asymmetricP1, keep=T)
dtwPlotTwoWay(align)


###################################################
### 그룹으로 묶어서 보여주기
###################################################
sc <- read.table("C:/Rpackages/data/synthetic_control.data", header=F, sep="")

# show one sample from each class
idx <- c(1,101,201,301,401,501)
sample1 <- t(sc[idx,])
plot.ts(sample1, main="제목")


###################################################
### 시계열 군집분석
###################################################
set.seed(6218)

n <- 10
s <- sample(1:100, n)
idx <- c(s, 100+s, 200+s, 300+s, 400+s, 500+s)
sample2 <- sc[idx,]
observedLabels <- rep(1:6, each=n)

# 유클리디안 거리 형태로 군집분석
hc <- hclust(dist(sample2), method="average")
plot(hc, labels=observedLabels, main="")

# 6개 군집으로 묶어서 보여주기
rect.hclust(hc, k=6)
memb <- cutree(hc, k=6)
table(observedLabels, memb)

###################################################
### DTW(Dynamic Time Warp) 라이브러리 시계열 군집분석
###################################################
library(dtw)
distMatrix <- dist(sample2, method="DTW")
hc <- hclust(distMatrix, method="average")
plot(hc, labels=observedLabels, main="")

# cut tree to get 6 clusters
rect.hclust(hc, k=6)
memb <- cutree(hc, k=6)
table(observedLabels, memb)


###################################################
### party 라이브러리 활용 시계열 군집분석
###################################################
classId <- rep(as.character(1:6), each=100)
newSc <- data.frame(cbind(classId, sc))
library(party)
ct <- ctree(classId ~ ., data=newSc, 
            controls = ctree_control(minsplit=30, minbucket=10, maxdepth=5))
pClassId <- predict(ct)
table(classId, pClassId)

# 정확도 : accuracy
(sum(classId==pClassId)) / nrow(sc)
plot(ct, ip_args=list(pval=FALSE), ep_args=list(digits=0))


###################################################
### wavelets 라이브러리 활용 시계열 군집분석
###################################################
library(wavelets)
wtData <- NULL
for (i in 1:nrow(sc)) {
  a <- t(sc[i,])
  wt <- dwt(a, filter="haar", boundary="periodic")
  wtData <- rbind(wtData, unlist(c(wt@W, wt@V[[wt@level]])))
}
wtData <- as.data.frame(wtData)
wtSc <- data.frame(cbind(classId, wtData))


###################################################
### decision tree with DWT coefficients
###################################################

ct <- ctree(classId ~ ., data=wtSc, 
            controls = ctree_control(minsplit=30, minbucket=10, maxdepth=5))
pClassId <- predict(ct)
table(classId, pClassId)
(sum(classId==pClassId)) / nrow(wtSc)
plot(ct, ip_args=list(pval=FALSE), ep_args=list(digits=0))


