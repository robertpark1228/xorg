###################################################
### 군집분석
###################################################
# free memory
rm(list = ls())
gc()

# 데이터 무작위 생성
set.seed(8953)

# iris : R에서 제공하는 붓꽃 데이터(설치하면 탑재되어 있음)
iris2 <- iris
iris2$Species <- NULL
(kmeans.result <- kmeans(iris2, 3))

# 데이터 테이블로 전환
table(iris$Species, kmeans.result$cluster)

# 기본 plot 그리기
plot(iris2[c("Sepal.Length", "Sepal.Width")], col = kmeans.result$cluster)

# 기본 plot에 중심점 그리기
points(kmeans.result$centers[,c("Sepal.Length", "Sepal.Width")], col = 1:3, pch = 8, cex=2)

# fpc 라이브러리 호출
library(fpc)
pamk.result <- pamk(iris2)

# 군집수 출력
pamk.result$nc
table(pamk.result$pamobject$clustering, iris$Species)

layout(matrix(c(1,2),1,2)) # 2 graphs per page

plot(pamk.result$pamobject)

layout(matrix(1)) # change back to one graph per page



# 다양한 시각화 출력 보기
set.seed(2835)

idx <- sample(1:dim(iris)[1], 40)
irisSample <- iris[idx,]
irisSample$Species <- NULL
hc <- hclust(dist(irisSample), method="ave")

plot(hc, hang = -1, labels=iris$Species[idx])

# cut tree into 3 clusters
rect.hclust(hc, k=3)
groups <- cutree(hc, k=3)


library(fpc)
iris2 <- iris[-5] # remove class tags
ds <- dbscan(iris2, eps=0.42, MinPts=5)
# compare clusters with original class labels
table(ds$cluster, iris$Species)

plot(ds, iris2)

plot(ds, iris2[c(1,4)])

plotcluster(iris2, ds$cluster)
